//AUTHOR:LUIS GUERRERO, JUAN LLANOS
//DATE:1/12/2020
//DESCRIPTION:PROYECTO PROGRAMACION SOFWARE EBSA
import javax.swing.*;
import java.awt.event.*;

public class Empezar extends JFrame implements ActionListener{
    JLabel  label2, label3;
    JButton boton1;
    public Empezar(){
        setLayout(null);
        setVisible(true);
        setBounds(0, 0, 500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setTitle("Empezar");

        label2 = new JLabel("Software EBSA");
        label2.setBounds(190, 50, 100, 100);
        add(label2);
        
        label3 = new JLabel("Version1.0");
        label3.setBounds(30, 220, 250, 30);
        add(label3);

        boton1 = new JButton("Empezar");
        boton1.setBounds(150, 150, 170, 40);
        boton1.addActionListener(this);
        add(boton1);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == boton1){
            Menu  menu1 = new Menu();
        }
    }
    public static void main(String[] args) throws Exception {
        Empezar empezar1 = new Empezar();
    }
}