//AUTHOR:LUIS GUERRERO, JUAN LLANOS
//DATE:1/12/2020
//DESCRIPTION:PROYECTO PROGRAMACION SOFWARE EBSA

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Menu extends JFrame implements ActionListener{
    JLabel label1, label2, label3;
    JButton boton1;
    JButton boton2;
    JButton boton3;
    public Menu(){
        setLayout(null);
        setVisible(true);
        setBounds(0, 0, 500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Menú");

        label2 = new JLabel("MENÚ PRINCIPAL");
        label2.setBounds(190, 10, 100, 100);
        add(label2);
        label3 = new JLabel("Creado por: Luis Guerrero Juan Llanos");
        label3.setBounds(130, 220, 300, 30);
        add(label3);
        boton1 = new JButton("Clientes");
        boton1.setBounds(160, 100, 150, 30);
        boton1.addActionListener(this);
        add(boton1);
        boton2 = new JButton("Facturas mensuales");
        boton2.setBounds(160, 140, 150, 30);
        boton2.addActionListener(this);
        add(boton2);

        boton3 = new JButton("Acerca de");
        boton3.setBounds(160, 180, 150, 30);
        boton3.addActionListener(this);
        add(boton3);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == boton1){
            Clientes clientes1 = new Clientes();
        }
        if(e.getSource() == boton2){
            Facturas factura1 = new Facturas();
        }
        if(e.getSource() == boton3){

            Acerca_de acerca_de1 = new Acerca_de();
        }
    }
    public static void main(String[] args) throws Exception {
        Menu  menu1 = new Menu();
    }

}