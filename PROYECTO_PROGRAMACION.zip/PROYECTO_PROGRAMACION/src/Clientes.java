//AUTHOR:LUIS GUERRERO, JUAN LLANOS
//DATE:1/12/2020
//DESCRIPTION:PROYECTO PROGRAMACION SOFWARE EBSA

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Clientes extends JFrame implements ActionListener{
    JLabel label1, label2, label3, label4, label5;
    JButton boton1;
    JTextField id, Nombre, Direccion, telefono, estrato;
    
    public Clientes(){
        setLayout(null);
        setVisible(true);
        setBounds(0, 0, 500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Clientes");

        label2 = new JLabel("Identificación:");
        label2.setBounds(30, 20, 360, 30);
        add(label2);
        id = new JTextField();
        id.setBounds(140, 22, 230, 25);
        add(id);
        
        label3 = new JLabel("Nombre completo:");
        label3.setBounds(30, 60, 360, 30);
        add(label3);
        Nombre = new JTextField();
        Nombre.setBounds(140, 62, 230, 25);
        add(Nombre);

        label4 = new JLabel("Direccion:");
        label4.setBounds(30, 100, 360, 25);
        add(label4);
        Direccion = new JTextField();
        Direccion.setBounds(140, 102, 230, 25);
        add(Direccion);


        label5 = new JLabel("Telefono:");
        label5.setBounds(30, 140, 360, 25);
        add(label5);
        telefono = new JTextField();
        telefono.setBounds(140, 142, 140, 25);
        add(telefono);

        label1 = new JLabel("Estrato:");
        label1.setBounds(290, 140, 360, 25);
        add(label1);
        estrato = new JTextField();
        estrato.setBounds(340, 142, 30, 25);
        add(estrato);


        boton1 = new JButton("Guardar");
        boton1.setBounds(150, 200, 150, 30);
        boton1.addActionListener(this);
        add(boton1);

    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == boton1){
         Menu  menu1 = new Menu();
        }
    
    }
    public static void main(String[] args) throws Exception {
        Clientes clientes1 = new Clientes();
    }

}