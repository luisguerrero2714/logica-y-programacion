//AUTHOR:LUIS GUERRERO, JUAN LLANOS
//DATE:1/12/2020
//DESCRIPTION:PROYECTO PROGRAMACION SOFWARE EBSA

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Acerca_de extends JFrame implements ActionListener{
    JLabel desarrollador, facultad, correo, github, desarrollador1, facultad1, correo1, github1;
    
    public Acerca_de(){
        setLayout(null);
        setVisible(true);
        setBounds(0, 0, 500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    
        setTitle("Acerca de");

        desarrollador = new JLabel("Desarrollador 1: Luis David Guerrero");
        desarrollador.setBounds(15, 20, 360, 30);
        add(desarrollador);

        desarrollador1 = new JLabel("Desarrollador 2: Juan Sebastan Llanos");
        desarrollador1.setBounds(260, 20, 360, 30);
        add(desarrollador1);
        
        facultad = new JLabel("Facultad: Ingenieria de Sistemas");
        facultad.setBounds(15, 50, 360, 30);
        add(facultad);

        facultad1 = new JLabel("Facultad: Ingenieria de Sistemas");
        facultad1.setBounds(260, 50, 360, 30);
        add(facultad1);

        correo = new JLabel("Correo: luis.guerrero@usantoto.edu.co");
        correo.setBounds(15, 80, 360, 30);
        add(correo);

        correo1 = new JLabel("Correo: Juan.llanos@usantoto.edu.co");
        correo1.setBounds(260, 80, 360, 30);
        add(correo1);

        github = new JLabel("Github:https://github.com/luisguerrero2714");
        github.setBounds(15, 110, 360, 30);
        add(github);
        
        github1 = new JLabel("Github:https://github.com/juanllanosc");
        github1.setBounds(260, 110, 360, 30);
        add(github1);
    }

    public static void main(String[] args) throws Exception {
        Acerca_de acerca_de1 = new Acerca_de();
    }
}